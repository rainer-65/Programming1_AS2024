package lecture09.examples.customer;

public enum AddressType {
	Billing, Delivery
}
