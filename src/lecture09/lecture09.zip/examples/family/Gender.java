package lecture09.examples.family;

public enum Gender {
	MALE, FEMALE
}
